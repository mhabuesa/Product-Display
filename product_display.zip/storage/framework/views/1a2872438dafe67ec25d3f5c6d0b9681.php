<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Sign In | DevHunter</title>

    <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/media/favicons/favicon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('assets')); ?>/media/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets')); ?>/media/favicons/apple-touch-icon-180x180.png">
    <link rel="stylesheet" id="css-main" href="<?php echo e(asset('assets')); ?>/css/oneui.min-5.9.css">

</head>
<body>
<div id="page-container">
          <main id="main-container">
<div class="hero-static d-flex align-items-center">
  <div class="content">
    <div class="row justify-content-center push">
      <div class="col-md-8 col-lg-6 col-xl-4">
        <div class="block block-rounded mb-0">
          <div class="block-header block-header-default">
            <h3 class="block-title">Sign In</h3>
          </div>
          <div class="block-content">
            <div class="p-sm-3 px-lg-4 px-xxl-5 py-lg-5">
              <h1 class="h2 mb-1">Chishti Agro</h1>
              <p class="fw-medium text-muted">
                Welcome, please login.
              </p>
              <form class="js-validation-signin" action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <div class="py-3">
                  <div class="mb-4">
                    <input type="text" class="form-control form-control-alt form-control-lg" id="login-username" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-4">
                    <input type="password" class="form-control form-control-alt form-control-lg" id="login-password" name="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-4">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" value="" id="login-remember" name="login-remember">
                      <label class="form-check-label" for="login-remember">Remember Me</label>
                    </div>
                  </div>
                </div>
                <div class="row mb-4">
                  <div class="col-md-6 col-xl-5">
                    <button type="submit" class="btn w-100 btn-alt-primary">
                      <i class="fa fa-fw fa-sign-in-alt me-1 opacity-50"></i> Sign In
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="fs-sm text-muted text-center">
      <strong>Qaseedah Shareef 1.0</strong> &copy; <span data-toggle="year-copy"></span>
    </div>
  </div>
</div>
  </main>
  </div>
<script src="<?php echo e(asset('assets')); ?>/js/oneui.app.min-5.9.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/lib/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/pages/op_auth_signin.min.js"></script>
</body>
</html>
<?php /**PATH G:\03. Project\product_display\resources\views\auth\login.blade.php ENDPATH**/ ?>