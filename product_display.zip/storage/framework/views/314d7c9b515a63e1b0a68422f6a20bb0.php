<?php $__env->startPush('title'); ?>
    <title>Product Details - Chishti Food Agro</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-body-light mt-4">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center py-2">
                <div class="flex-grow-1">
                    <h1 class="h3 fw-bold mb-1">
                        Product Details
                    </h1>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="block block-rounded">
                    <div class="block-header block-header-default">
                        <h3 class="block-title">
                            Product Details
                        </h3>
                    </div>
                    <div class="block-content">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="block-content">
                                    <div class="row">
                                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img class="col-lg-5" src="<?php echo e(asset($gallery->gallery_image)); ?>" width="50" alt="" >
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="mt-3">
                                    <h3>Product Name: <?php echo e($product->name); ?></h3>
                                    <p>Description: <?php echo e($product->description); ?></p>
                                    <p>Price: <?php echo e($product->price); ?></p>
                                    <p>Brand: <?php echo e($product->brand->name); ?></p>
                                    <p>Group: <?php echo e($product->group->name); ?></p>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\03. Project\product_display\resources\views\backend\product\product_details.blade.php ENDPATH**/ ?>