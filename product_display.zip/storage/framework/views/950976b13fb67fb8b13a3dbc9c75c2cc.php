<?php $__env->startPush('title'); ?>
    <title>Dashboard - Chishti Food Agro</title>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/js/plugins/datatables-bs5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons-bs5/css/buttons.bootstrap5.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets')); ?>/js/plugins/datatables-responsive-bs5/css/responsive.bootstrap5.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/js/plugins/slick-carousel/slick.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/js/plugins/slick-carousel/slick-theme.css">
    <link rel="stylesheet" id="css-main" href="<?php echo e(asset('assets')); ?>/css/oneui.min-5.9.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="bg-body-light mt-4">
    <div class="content content-full">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center py-2">
            <div class="flex-grow-1">
                <h1 class="h3 fw-bold mb-1">
                    Dashboard
                </h1>
            </div>
        </div>
    </div>
</div>
<div class="content">
    <div class="row">

        <div class="col-md-6">
          <div class="block block-rounded">
            <div class="block-header block-header-default">
              <h3 class="block-title">
                All Brands
              </h3>
            </div>
            <div class="block-content">
              <div class="js-slider text-center" data-autoplay="true" data-dots="true" data-arrows="true" data-slides-to-show="3">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="py-3">
                    <a class="text-dark" href=" <?php echo e(route('brands.products', $brand->id)); ?>">
                        <img class="img-avatar" src="<?php echo e($brand->image); ?>" alt="">
                        <div class="mt-2 fw-semibold"><?php echo e($brand->name); ?></div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="block block-rounded">
            <div class="block-header block-header-default">
              <h3 class="block-title">
                All Groups
              </h3>
            </div>
            <div class="block-content">
              <div class="js-slider text-center" data-autoplay="true" data-dots="true" data-arrows="true" data-slides-to-show="3">
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="py-3">
                    <a class="text-dark" href=" <?php echo e(route('groups.products', $group->id)); ?>">
                        <img class="img-avatar" src="<?php echo e($group->image); ?>" alt="">
                        <div class="mt-2 fw-semibold"><?php echo e($group->name); ?></div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-12">
            <div class="block block-rounded">
                <div class="block-header block-header-default">
                    <h3 class="block-title">
                        All Products
                    </h3>
                </div>
                <div class="block-content block-content-full overflow-x-auto">
                    <table class="table table-bordered table-striped table-vcenter" id="productsTable">
                        <thead>
                            <tr>
                                <th class="text-center">SL</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Brand</th>
                                <th>Group</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center fs-sm"><?php echo e($key + 1); ?></td>
                                    <td class="fs-sm">
                                        <img src="<?php echo e(asset($product->thumbnail_image)); ?>" width="50px" alt="">
                                    </td>
                                    <td class="fw-semibold fs-sm"><?php echo e($product->name); ?></td>
                                    <td class="fw-semibold fs-sm"><?php echo e($product->brand->name); ?></td>
                                    <td class="fw-semibold fs-sm"><?php echo e($product->group->name); ?></td>
                                    <td class="fw-semibold fs-sm"><?php echo e($product->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables/dataTables.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-bs5/js/dataTables.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons-jszip/jszip.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons-pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons-pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/plugins/datatables-buttons/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/pages/be_tables_datatables.min.js"></script>

    <script>
        $('#productsTable').DataTable();
    </script>
    <script src="assets/js/plugins/slick-carousel/slick.min.js"></script>
    <script>One.helpersOnLoad(['jq-slick']);</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\03. Project\product_display\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>