<?php $__env->startPush('title'); ?>
    <title><?php echo e($brand->name); ?> Brand Products - Chishti Food Agro</title>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="bg-body-light mt-4">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center py-2">
                <div class="flex-grow-1">
                    <h1 class="h3 fw-bold mb-1">
                        <?php echo e($brand->name); ?>

                    </h1>
                </div>
                <nav class="flex-shrink-0 mt-3 mt-sm-0 ms-sm-3" aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-alt">
                        <li class="breadcrumb-item">
                            <a class="link-fx" href="javascript:void(0)">Products</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        <img class="mx-auto d-block" src="<?php echo e(asset($product->thumbnail_image)); ?>" alt="" width="100" >
                        <h3 class="text-center mb-0"><a href="<?php echo e(route('products.details', $product->id)); ?>"><?php echo e($product->name); ?></a></h3>
                        <span class="text-center mx-auto d-block mt-1">Price: <?php echo e($product->price); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\03. Project\product_display\resources\views\backend\brand\brands_products.blade.php ENDPATH**/ ?>